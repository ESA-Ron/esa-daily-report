# ESA Daily Report — Deploy to Render.com

## What's in this folder
- app.py          → the server (handles file uploads, calls Claude API)
- requirements.txt → Python packages needed
- render.yaml     → Render hosting config
- static/
  └── index.html  → the beautiful web interface

## How to deploy (do this once, takes ~5 minutes)

### Step 1 — Put this folder on GitHub
1. Go to github.com and sign up for a free account if you don't have one
2. Click the green "New" button to create a new repository
3. Name it: esa-daily-report
4. Click "Create repository"
5. On the next page, click "uploading an existing file"
6. Drag ALL files from this folder into the upload area:
   - app.py
   - requirements.txt
   - render.yaml
   - static/index.html  (upload this into a folder called "static")
7. Click "Commit changes"

### Step 2 — Deploy on Render.com
1. Go to render.com and sign up free (use your GitHub account to sign in)
2. Click "New +" → "Web Service"
3. Click "Connect" next to your esa-daily-report repository
4. Render will auto-fill everything from render.yaml — just click "Create Web Service"
5. Wait about 2 minutes for it to build
6. Your app will be live at:  https://esa-daily-report.onrender.com

### Step 3 — Bookmark it
Bookmark the URL. That's your tool — open it any time from any browser.

## How to use it every morning
1. Open your bookmarked URL
2. Drop your ESA Bookings file onto the first box
3. Optionally drop the Mapping file onto the second box (adds salesperson leaderboard)
4. Paste your Claude API key (get free key at console.anthropic.com)
5. Click "Run Daily Report"
6. Wait ~45 seconds
7. Click "Copy — Paste into Outlook"
8. Done!

## Notes
- The free Render plan "spins down" after 15 minutes of no use.
  First load after inactivity takes ~30 seconds. After that it's instant.
- To keep it always-on, upgrade to Render's $7/month plan (optional).
- Your API key is never stored on the server — it's sent with each request only.
